package com.example.class2demo24.Model

data class Student (var name: String, var id:String, val avatar:String, var isChecked:Boolean){
}