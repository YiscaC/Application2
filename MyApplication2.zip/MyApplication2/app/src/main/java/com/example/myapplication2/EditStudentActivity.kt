package com.example.myapplication2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.class2demo24.Model.Model
import com.example.myapplication2.R

class EditStudentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_student)

        val studentId = intent.getStringExtra("STUDENT_ID")
        val student = Model.instance.students.find { it.id == studentId }

        if (student != null) {

            val nameInput = findViewById<EditText>(R.id.name_input)
            val idInput = findViewById<EditText>(R.id.id_input)
            val cleanId = student.id.replace("Id: ", "")
            val cleanName = student.name.replace("Name: ", "")
            idInput.setText(cleanId)
            nameInput.setText(cleanName)

            findViewById<Button>(R.id.save_button).setOnClickListener {
                student.name =  nameInput.text.toString()
                student.id = idInput.text.toString()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

            }

            findViewById<Button>(R.id.delete_button).setOnClickListener {
                Model.instance.students.remove(student)
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)

            }
        }
    }
}
