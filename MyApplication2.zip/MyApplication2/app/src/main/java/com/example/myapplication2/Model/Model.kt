package com.example.class2demo24.Model


import java.util.jar.Attributes.Name

import kotlin.random.Random

class Model private constructor() {

    val students: MutableList<Student> = ArrayList()

    companion object {
        val instance: Model = Model()
    }

    init {
        // יוצר סטודנטים לדוגמה בעזרת הפונקציה generateStudents
        generateStudents(students, 10) // ניתן לשנות את המספר כדי לקבוע כמה תלמידים ייווצרו
    }

    private fun generateStudents(students: MutableList<Student>, count: Int) {
        val commonNames = listOf(
            "James", "John", "Robert", "Michael", "David",
            "William", "Joseph", "Charles", "Thomas", "Daniel",
            "Matthew", "Mark", "Andrew", "Joshua", "Nicholas",
            "Samuel", "Ryan", "Benjamin", "Adam", "Christopher"
        )

        for (i in 1..count) {
            // בוחר שם אקראי מרשימת שמות נפוצים
            val name = commonNames.random()

            // יוצר מספר תעודת זהות בת 9 ספרות
            val id = (100_000_000..999_999_999).random().toString()

            // יוצר אובייקט סטודנט ומוסיף אותו לרשימה
            val student = Student("Name:$name", "Id: $id", "https://me.com/avatar.jpg", false)
            students.add(student)
        }
    }
}





