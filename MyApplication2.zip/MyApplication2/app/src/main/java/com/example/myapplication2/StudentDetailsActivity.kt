package com.example.myapplication2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.class2demo24.Model.Model
import com.example.myapplication2.R

class StudentDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_details)

        val studentId = intent.getStringExtra("STUDENT_ID")
        val student = Model.instance.students.find { it.id == studentId }

        if (student != null) {

            findViewById<TextView>(R.id.student_name).text = student.name
            findViewById<TextView>(R.id.student_id).text = student.id

            findViewById<Button>(R.id.edit_button).setOnClickListener {
                val intent = Intent(this, EditStudentActivity::class.java)
                intent.putExtra("STUDENT_ID", student.id)
                startActivity(intent)
            }
        }
    }
}


