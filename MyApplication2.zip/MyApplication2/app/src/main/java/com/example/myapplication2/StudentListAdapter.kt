package com.example.myapplication2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.class2demo24.Model.Student
import com.example.myapplication2.R
import com.squareup.picasso.Picasso

class StudentListAdapter(
    private val students: List<Student>,
    private val onRowClick: (Student) -> Unit
) : RecyclerView.Adapter<StudentListAdapter.StudentViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.student_row, parent, false)
        return StudentViewHolder(view)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val student = students[position]
        holder.bind(student, onRowClick)
    }

    override fun getItemCount(): Int = students.size

    class StudentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val nameTextView: TextView = view.findViewById(R.id.student_name)
        private val idTextView: TextView = view.findViewById(R.id.student_id)
        private val avatarImageView: ImageView = view.findViewById(R.id.student_avatar)
        private val checkBox: CheckBox = view.findViewById(R.id.student_checkbox)

        fun bind(student: Student, onRowClick: (Student) -> Unit) {
            nameTextView.text = student.name
            idTextView.text = student.id
            Picasso.get().load(student.avatar).into(avatarImageView)
            checkBox.isChecked = student.isChecked

            checkBox.setOnCheckedChangeListener { _, isChecked ->
                student.isChecked = isChecked
            }

            itemView.setOnClickListener { onRowClick(student) }
        }
    }
}
